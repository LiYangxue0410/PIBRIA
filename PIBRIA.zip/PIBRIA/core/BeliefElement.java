package keel.Algorithms.Fuzzy_Rule_Learning.Hybrid.PIBRIA.core;

import java.util.Arrays;

public class BeliefElement {
    double [] elements=null;
    double belief=0.0;

    public BeliefElement(double[] elements, double belief){
        this.elements=elements.clone();
        this.belief=belief;
    }

    public void setElements(double[] elements){
        this.elements=elements.clone();
    }

    public void setBelief(double belief){
        this.belief=belief;
    }

    public double[] getElements(){
        return this.elements;
    }

    public double getBelief(){
        return this.belief;
    }

    public BeliefElement Fusion(BeliefElement bef){
        int numSame=0;
        for (int i=0;i<this.getElements().length;i++){
            for (int j =0;j<bef.getElements().length;j++){
                if (this.getElements()[i]==bef.getElements()[j]){
                    numSame+=1;
                }
            }
        }
        double [] newElements=new double [numSame];
        int w=0;
        for (int i=0;i<this.getElements().length;i++){
            for (int j =0;j<bef.getElements().length;j++){
                if (this.getElements()[i]==bef.getElements()[j]){
                    newElements[w]=this.getElements()[i];
                    w++;
                }
            }
        }
        BeliefElement newBef=new BeliefElement(newElements, this.getBelief()*bef.getBelief());
        return newBef;
    }
    public boolean isEmpty(){
        if(this.elements.length==0){
            return true;
        }else{
            return false;
        }
    }

    public boolean elementEqual(BeliefElement belele){
        double[] ele1=this.getElements();
        double[] ele2=belele.getElements();
        Arrays.sort(ele1);
        Arrays.sort(ele2);
        if(Arrays.equals(ele1, ele2)){
            return true;
        }else{
            return false;
        }
    }
}
