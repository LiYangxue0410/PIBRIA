package keel.Algorithms.Fuzzy_Rule_Learning.Hybrid.PIBRIA.core;

import java.util.ArrayList;

public class BeliefFunction {
    ArrayList<BeliefElement> bpa=new ArrayList<>(0);

    public BeliefFunction(ArrayList<BeliefElement> bpa1){
        for (int i =0;i<bpa1.size();i++){
            this.bpa.add(bpa1.get(i));
        }
    }
    public BeliefFunction(){
        this.bpa=new ArrayList<>(0);
    }
    public BeliefElement getElement(int i){
        return this.bpa.get(i);
    }
    public void addElement(BeliefElement ele){
        this.bpa.add(ele);
    }
    public int getSize(){
        return this.bpa.size();
    }
    private void normalize(){
        double sum=0;
        for(int i =0;i<this.getSize();i++){
            BeliefElement ele=this.getElement(i);
            sum+=ele.getBelief();
        }
        for(int i=0;i<this.getSize();i++){
            BeliefElement ele=this.getElement(i);
            ele.setBelief(ele.getBelief()/sum);
        }
    }
    
    public BeliefFunction BPAFusion(BeliefFunction bpa1){
        BeliefFunction newbpa=new BeliefFunction();
        for(int i=0;i<this.getSize();i++){
            BeliefElement elei=this.getElement(i);
            for ( int j=0;j<bpa1.getSize();j++){
                BeliefElement elej=bpa1.getElement(j);
                BeliefElement newele=elei.Fusion(elej);
                if(!newele.isEmpty()){
                    if( newbpa.getSize()!=0){
                        boolean inBPA=false;
                        for(int k=0;k<newbpa.getSize();k++){
                            BeliefElement elek=newbpa.getElement(k);
                            if(newele.elementEqual(elek)){
                                elek.setBelief(elek.getBelief()+newele.getBelief());
                                inBPA=true;
                                break;
                            }
                        }
                        if(!inBPA){
                            newbpa.addElement(newele);
                        }
                    }else{
                        newbpa.addElement(newele);
                    }
                }
            }
        }
        newbpa.normalize();
        return newbpa;
    }

    public double[] BPAtoDistribution(int numClass){
        double[] distribution = new double[numClass];  
		for (int i=0;i<numClass;i++){
			distribution[i]=0;
		}
        for(int i =0;i<this.getSize();i++){
            BeliefElement ele=this.getElement(i);
            for ( int j=0;j<ele.getElements().length;j++){
                distribution[(int)ele.getElements()[j]]+=ele.getBelief()/ele.getElements().length;
            }
        }
        return distribution;
    }
}